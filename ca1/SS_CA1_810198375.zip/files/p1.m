function det  = p1(matrix_2d)
det = matrix_2d(1) * matrix_2d(4) - matrix_2d(2) * matrix_2d(3);
end
